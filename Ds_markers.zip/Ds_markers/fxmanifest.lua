version '1.0.0'
author 'Ds Studio'
description 'Makes Custom 3d Markers'
repository 'https://github.com/citizenfx/cfx-server-data'

client_script 'client/client.lua'

fx_version 'cerulean'
game 'gta5'